from beverage import Beverage

class Qator:
    def __init__(self, number,son) -> None:
        self._number = number
        self._son = son
        self._name = ''
        self._s = 0
        self._ichimliklist: list[Beverage] = []

    def add_beverage(self, beverage: Beverage):
        # if self._name == beverage.name:
        self._name = beverage.name
        self._number = beverage._number
        self._son = beverage._son
        self._ichimliklist.append(beverage)
        return 'qo\'shildi'
        # return 'qo\'sha olmadim'
    
    def getlist(self):
        for i in self._ichimliklist:
            print(i.name, '-->', i.price)
    def availableCans(self):
        for i in self._ichimliklist:
            self._s+=self._son
            print("soni -->",self._s)
    def refillcolumn(self):
        Qator.add_beverage()
    