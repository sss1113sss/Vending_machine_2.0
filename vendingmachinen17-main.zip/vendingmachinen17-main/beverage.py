class Beverage:
    def __init__(self, name, price,number,son) -> None:
        self._name = name
        self._price = price
        self._number = number
        self._son = son
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, value):
        self._name = value
    @property
    def price(self):
        return self._price
    @price.setter
    def price(self, value):
        self._price = value
    @property
    def price(self):
        return self._number
    @price.setter
    def price(self, value):
        self._number = value
    @property
    def price(self):
        return self._son
    @price.setter
    def price(self, value):
        self._son = value    
